# Ficheros

Uno de los métodos más comunes para almacenar información es a través de ficheros. Un fichero es un conjunto de datos que se almacenan en un dispositivo de almacenamiento y que pueden ser accedidos y manipulados por un sistema informático.

Los ficheros pueden contener diferentes tipos de información, como texto, imágenes, audio, video o cualquier otro tipo de datos. Cada fichero tiene un nombre único y una extensión (opcional) que indica el tipo de contenido que contiene. Por ejemplo, un fichero de texto puede tener la extensión ".txt", mientras que un fichero de imagen puede tener la extensión ".jpg" o ".png".

El nombre de un fichero es obligatorio y debe ser único dentro de un mismo directorio o carpeta. La extensión del fichero es opcional, pero es útil para identificar el tipo de contenido que contiene y para asociarlo con aplicaciones específicas que pueden abrirlo.

Los ficheros se organizan en un sistema de archivos, que es una estructura jerárquica que permite almacenar y acceder a los ficheros de manera eficiente. Los sistemas de archivos pueden variar según el sistema operativo y el dispositivo de almacenamiento utilizado.

Podemos clasificar los ficheros en diferentes tipos según su contenido y formato. Algunos de los tipos de ficheros más comunes incluyen:

* **Ficheros de texto**: Contienen información en formato de texto plano y pueden ser abiertos y editados con cualquier editor de texto. Ejemplos de ficheros de texto incluyen archivos con extensiones como ".txt", ".csv" o ".log".
* **Ficheros binarios**: Contienen información en formato binario y no pueden ser abiertos directamente con un editor de texto. Ejemplos de ficheros binarios incluyen archivos con extensiones como ".exe", ".dll" o ".bin".

En función del tipo de información que contienen, los ficheros pueden ser clasificados en diferentes categorías, como ficheros de datos, ficheros de configuración, ficheros de registro, entre otros. Cada categoría tiene un propósito específico y se utiliza en diferentes contextos dentro de un sistema informático.


## Ficheros de texto

Como hemos comentado anteriormente, los ficheros de texto son aquellos que contienen información en formato de texto plano y pueden ser abiertos y editados con cualquier editor de texto. Estos ficheros son legibles para los humanos y pueden contener caracteres alfanuméricos, símbolos y espacios.

Estos simbolos pueden ser un propio texto, o utilizar un lenguaje de marcado como HTML, XML o Markdown para estructurar y dar formato a la información contenida en el fichero. Los ficheros de texto son ampliamente utilizados para almacenar información que necesita ser leída y comprendida por personas, como documentos, notas, scripts y archivos de configuración.

!!! info
    Este documento que estas leyendo, ha sido creado usando el lenguaje de marcado Markdown, y se encuentra almacenado en un fichero de texto con la extensión ".md". Además se ha exportado a formato HTML para su visualización en la web.

## Ficheros binarios

Los ficheros binarios son aquellos que contienen información en formato binario y no pueden ser abiertos directamente con un editor de texto. Estos ficheros están diseñados para ser interpretados por programas específicos que pueden leer y procesar la información contenida en ellos.

Podemos encontrar diferentes tipos de ficheros binarios, como ejecutables, bibliotecas, imágenes, audio y video. Cada tipo de fichero binario tiene un propósito específico y requiere un software adecuado para su apertura y manipulación.

Existen diferentes formatos de ficheros binarios, cada uno con sus propias características y ventajas. Algunos ejemplos de formatos de ficheros binarios incluyen:

* **Ficheros ejecutables**: Contienen instrucciones que pueden ser ejecutadas por un sistema operativo para realizar tareas específicas. Ejemplos de ficheros ejecutables incluyen archivos con extensiones como ".exe" en Windows o ".app" en macOS.
* **Ficheros de imagen**: Contienen información visual que puede ser mostrada en una pantalla o impresa en papel. Ejemplos de ficheros de imagen incluyen archivos con extensiones como ".jpg", ".png" o ".gif".
* **Ficheros de audio: Contienen información de sonido que puede ser reproducida por un sistema de audio. Ejemplos de ficheros de audio incluyen archivos con extensiones como ".mp3", ".wav" o ".flac".
* **Ficheros de video**: Contienen información visual y de sonido que puede ser reproducida por un sistema de video. Ejemplos de ficheros de video incluyen archivos con extensiones como ".mp4", ".avi" o ".mkv".
* **Ficheros de biblioteca**: Contienen código y recursos que pueden ser utilizados por otros programas para realizar tareas específicas. Ejemplos de ficheros de biblioteca incluyen archivos con extensiones como ".dll" en Windows o ".so" en Linux.
* **Ficheros de datos**: Contienen información estructurada que puede ser utilizada por programas para realizar análisis y procesamiento de datos. Ejemplos de ficheros de datos incluyen archivos con extensiones como ".bin" o ".dat".

### Ficheros de datos

Vamos a centrarnos en los ficheros de datos; estos ficheros contienen información estructurada que puede ser utilizada por programas para realizar análisis y procesamiento de datos. Los ficheros de datos pueden almacenar diferentes tipos de información, como números, texto, fechas, booleanos y otros tipos de datos.

En muchas ocasiones, estos datos estan almacenados en un formato específico que permite su fácil lectura y manipulación por parte de programas y aplicaciones. Podemos definir estos formatos con la siguiente clasificación:

* **Campo**: Es la unidad más pequeña de información en un fichero de datos. Un campo puede contener un solo valor, como un número, una cadena de texto o una fecha. Por ejemplo, en un fichero de datos que almacena información de clientes, un campo podría ser el nombre del cliente o su dirección de correo electrónico.
* **Registro**: Es un conjunto de campos relacionados que representan una entidad o un objeto en el fichero de datos. Por ejemplo, un registro podría contener información sobre un cliente, incluyendo su nombre, dirección, número de teléfono y correo electrónico. Cada registro se almacena como una unidad completa en el fichero de datos y puede ser accedido y manipulado de manera independiente.
* **Archivo**: Es un conjunto de registros relacionados que se almacenan en un fichero de datos. Un archivo puede contener múltiples registros, cada uno representando una entidad o un objeto diferente. Por ejemplo, un archivo podría contener información sobre todos los clientes de una empresa, con cada registro representando a un cliente individual. Los archivos se organizan en un sistema de archivos y pueden ser accedidos y manipulados de manera eficiente por programas y aplicaciones.

## Clasificación de ficheros en función de su uso

Podemos clasificar los ficheros en función de su uso y propósito dentro de un sistema informático. Esta clasificación nos permite entender mejor cómo se utilizan los ficheros y qué tipo de información contienen. Algunos ejemplos de clasificación de ficheros según su uso incluyen:

* **Fichero Maestro**: Es un fichero que contiene información principal y estructurada sobre una entidad o un objeto. Por ejemplo, un fichero maestro de clientes podría contener información detallada sobre cada cliente, incluyendo su nombre, dirección, número de teléfono y correo electrónico.
* **Fichero de Transacciones**: Es un fichero que contiene información sobre eventos o transacciones que ocurren en un sistema informático. Por ejemplo, un fichero de transacciones podría registrar cada compra realizada por un cliente, incluyendo la fecha, el monto y los productos adquiridos. Estos ficheros son utilizados para llevar un registro de las actividades y operaciones que se realizan en un sistema.
* **Fichero Histórico**: Es un fichero que contiene información histórica o archivada sobre una entidad o un objeto. Por ejemplo, un fichero histórico de clientes podría contener información sobre clientes que ya no están activos, incluyendo sus datos de contacto y el historial de transacciones realizadas. Estos ficheros son utilizados para mantener un registro de la información pasada y pueden ser consultados para análisis y referencia futura.

## Acceso a ficheros

Otro aspecto importante a considerar es el acceso a los ficheros. El acceso a ficheros se refiere a la forma en que los programas y aplicaciones pueden leer, escribir y manipular la información contenida en los ficheros.

Existen diferentes métodos de acceso a ficheros, que pueden variar según el sistema operativo y el tipo de fichero. Algunos de los métodos de acceso a ficheros más comunes incluyen:

* **Acceso secuencial**: En este método, los datos se leen o escriben en un orden específico, uno tras otro. Este tipo de acceso es eficiente para ficheros grandes y cuando se necesita procesar toda la información de manera lineal. Sin embargo, puede ser menos eficiente si se requiere acceder a datos específicos dentro del fichero.
* **Acceso aleatorio**: En este método, los datos pueden ser leídos o escritos en cualquier orden, lo que permite un acceso más rápido a información específica dentro del fichero. Este tipo de acceso es útil para ficheros que contienen grandes cantidades de datos y cuando se necesita acceder a información específica de manera rápida y eficiente. Sin embargo, puede requerir más recursos y complejidad en la gestión del fichero, ya que se necesita un sistema de indexación o una estructura de datos que permita localizar rápidamente la información deseada.
* **Acceso directo**: En este método, los datos se acceden directamente mediante una dirección o un identificador único, lo que permite un acceso rápido y eficiente a información específica dentro del fichero. Este tipo de acceso es útil para ficheros que contienen grandes cantidades de datos y cuando se necesita acceder a información específica de manera rápida y eficiente. Sin embargo, puede requerir más recursos y complejidad en la gestión del fichero, ya que se necesita un sistema de indexación o una estructura de datos que permita localizar rápidamente la información deseada.

A continuación, vamos a ver cada uno de este tipo de ficheros.

### Acceso secuencial

El acceso secuencial es un método de acceso a ficheros en el que los datos se leen o escriben en un orden específico, uno tras otro. Este tipo de acceso es eficiente para ficheros grandes y cuando se necesita procesar toda la información de manera lineal. Sin embargo, puede ser menos eficiente si se requiere acceder a datos específicos dentro del fichero, ya que se debe recorrer todo el fichero hasta llegar a la información deseada.

Algunas de sus características principales del acceso secuencial incluyen:

* **Ventajas:** Máximo aprovechamiento del espacio en disco (sin huecos), ideal para procesar grandes volúmenes de datos masivos (procesos *batch*).
* **Inconvenientes:** Búsqueda lenta $\mathcal{O}(N)$. Para modificar o insertar un registro intermedio, se requiere rehacer o crear una copia completa del fichero.
* **Operaciones Clave:** Lectura secuencial, mezcla de ficheros ordenados (*Sort-Merge*), actualización por lotes mediante fichero de transacciones.

### Acceso aleatorio

El acceso aleatorio es un método de acceso a ficheros en el que los datos pueden ser leídos o escritos en cualquier orden, lo que permite un acceso más rápido a información específica dentro del fichero. Este tipo de acceso es útil para ficheros que contienen grandes cantidades de datos y cuando se necesita acceder a información específica de manera rápida y eficiente. Sin embargo, puede requerir más recursos y complejidad en la gestión del fichero, ya que se necesita un sistema de indexación o una estructura de datos que permita localizar rápidamente la información deseada.

Algunas de sus características principales del acceso aleatorio incluyen:

* **Ventajas:** Permite acceder a registros específicos de manera rápida y eficiente, ideal para ficheros que contienen grandes cantidades de datos.
* **Inconvenientes:** Requiere más recursos y complejidad en la gestión del fichero, ya que se necesita un sistema de indexación o una estructura de datos que permita localizar rápidamente la información deseada.
* **Operaciones Clave:** Lectura y escritura de registros específicos, actualización de registros individuales, eliminación de registros específicos.

### Acceso directo (Indexado)

El acceso directo es un método de acceso a ficheros en el que los datos se acceden directamente mediante una dirección o un identificador único, lo que permite un acceso rápido y eficiente a información específica dentro del fichero. Este tipo de acceso es útil para ficheros que contienen grandes cantidades de datos y cuando se necesita acceder a información específica de manera rápida y eficiente. Sin embargo, puede requerir más recursos y complejidad en la gestión del fichero, ya que se necesita un sistema de indexación o una estructura de datos que permita localizar rápidamente la información deseada.

Algunas de sus características principales del acceso directo incluyen:

* **Ventajas:** Permite acceder a registros específicos de manera rápida y eficiente, ideal para ficheros que contienen grandes cantidades de datos.
* **Inconvenientes:** Requiere más recursos y complejidad en la gestión del fichero, ya que se necesita un sistema de indexación o una estructura de datos que permita localizar rápidamente la información deseada.
* **Operaciones Clave:** Lectura y escritura de registros específicos, actualización de registros individuales, eliminación de registros específicos.

Normalmente este tipo de ficheros se basa en la utilización de un índice que permite localizar rápidamente la información deseada dentro del fichero. El índice puede ser una estructura de datos como un árbol B o un hash, que permite acceder a los registros de manera eficiente y rápida.

Podemos definir que el acceso directo es una combinación de los métodos de acceso secuencial y aleatorio, ya que permite acceder a registros específicos de manera rápida y eficiente, pero también permite procesar toda la información de manera lineal si es necesario.

Se utiliza principalmente en bases de datos y sistemas de gestión de información donde se requiere un acceso rápido y eficiente a grandes volúmenes de datos.

Un fichero indexado (o directo), se divide en las siguientes partes:

* **Datos**: Contienen la información principal del fichero, organizada en registros y campos.
* **Índice**: Contiene información sobre la ubicación de los registros dentro del fichero de datos, lo que permite acceder a ellos de manera rápida y eficiente.

### Tipos de índices

Existen diferentes tipos de índices que se utilizan en ficheros indexados para mejorar el acceso a la información. Algunos de los tipos de índices más comunes incluyen:

* **Índice Denso:** Contiene una entrada en la tabla de índices por cada registro presente en el fichero.
* **Índice No Denso (Esparcido):** Contiene una entrada por cada bloque o página de memoria.
* **Estructuras ISAM y Árboles B / B+:**
  * **ISAM (Indexed Sequential Access Method):** Índice multinivel rígido ligado a la estructura física del disco.
  * **Árboles B+:** Estructura en árbol auto-balanceada donde todos los datos residen en las hojas y los nodos internos forman el índice. Es la estructura estándar utilizada en los motores de bases de datos modernos.