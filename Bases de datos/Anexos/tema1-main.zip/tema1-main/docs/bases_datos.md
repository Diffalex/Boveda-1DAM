# Bases de datos

Hemos visto que el almacenamiento en ficheros es un método común para guardar información, pero a medida que los datos crecen en volumen y complejidad, surge la necesidad de utilizar bases de datos para gestionar y organizar la información de manera más eficiente.

A la hora de trabajar con sistemas con muchos ficheros pueden aparecer los siguientes inconvenientes:

* Dificultad para mantener la integridad de los datos: Cuando se almacenan datos en múltiples ficheros, puede ser difícil garantizar que la información sea consistente y precisa. Por ejemplo, si un dato se actualiza en un fichero pero no en otro, puede generar inconsistencias y errores en el sistema.
* Problemas de redundancia: Almacenar datos en múltiples ficheros puede llevar a la duplicación de información, lo que aumenta el riesgo de errores y dificulta la gestión de los datos.
* Dificultad para realizar consultas complejas: Cuando los datos están dispersos en múltiples ficheros, puede ser complicado realizar consultas que involucren información de diferentes fuentes. Esto puede limitar la capacidad de obtener información valiosa y tomar decisiones informadas.
* Dependencia entre los datos y el programa: Cuando los datos están estrechamente vinculados a la estructura de los ficheros y al código del programa, cualquier cambio en los datos puede requerir modificaciones en el programa, lo que aumenta la complejidad y el riesgo de errores.
* Dificultad para acceso concurrente: Cuando múltiples usuarios intentan acceder y modificar los datos al mismo tiempo, puede surgir problemas de concurrencia y bloqueo, lo que puede afectar el rendimiento y la disponibilidad del sistema.
* Falta de seguridad y control de acceso: Almacenar datos en ficheros puede dificultar la implementación de medidas de seguridad y control de acceso, lo que aumenta el riesgo de accesos no autorizados y pérdida de información sensible.

### Definición de base de datos

Una base de datos (BD) es un sistema organizado de almacenamiento de información que permite gestionar grandes volúmenes de datos de manera eficiente. A diferencia del almacenamiento en ficheros, las bases de datos ofrecen una estructura más flexible y permiten realizar consultas complejas, mantener la integridad de los datos y facilitar el acceso concurrente por parte de múltiples usuarios.

Existen diferentes tipos de bases de datos, cada una con sus propias características y ventajas. Algunos de los tipos más comunes incluyen:

* **Bases de datos relacionales (RDB)**: Organizan los datos en tablas con filas y columnas, y utilizan un lenguaje de consulta estructurado (SQL) para acceder y manipular la información. Son ampliamente utilizadas en aplicaciones empresariales y sistemas de gestión de datos.
* **Bases de datos orientadas a objetos (OODB)**: Almacenan los datos como objetos, que incluyen tanto los datos como los métodos asociados. Son ideales para aplicaciones que requieren una representación más natural de los datos y permiten una mayor flexibilidad en la gestión de la información.
* **Bases de datos jerárquicas**: Organizan los datos en una estructura de árbol, donde cada registro tiene un único padre y puede tener múltiples hijos. Son útiles para representar relaciones jerárquicas, como la estructura de una organización o un catálogo de productos.
* **Bases de datos NoSQL _(Not Only SQL)_**: Diseñadas para manejar grandes volúmenes de datos no estructurados o semi-estructurados, como documentos, gráficos y datos en tiempo real. Son ideales para aplicaciones web y móviles que requieren escalabilidad y flexibilidad.

## Como funcionan las bases de datos

Una base de datos funciona mediante un sistema de gestión de bases de datos (SGBD), que es un software que permite crear, administrar y manipular la base de datos. El SGBD proporciona una interfaz para que los usuarios puedan interactuar con la base de datos, realizar consultas, insertar, actualizar y eliminar datos, así como garantizar la integridad y seguridad de la información.

A la hora de trabajar con bases de datos, es importante tener en cuenta como trabaja los datos el SGBD, ya que este se encarga de organizar y gestionar la información de manera eficiente. Además, el SGBD permite definir la estructura de la base de datos, establecer relaciones entre los datos y aplicar reglas de integridad para garantizar la consistencia de la información.

### Tipos de bases de datos en función de su estructura

Podemos definir los siguientes tipos de bases de datos en función de su estructura:

* **Bases de datos estáticas**: Son aquellas que no cambian con frecuencia y se utilizan principalmente para almacenar información histórica o de referencia. Por ejemplo, una base de datos que contiene información sobre productos antiguos o registros históricos.
* **Bases de datos dinámicas**: Son aquellas que se actualizan y modifican con frecuencia, permitiendo a los usuarios agregar, eliminar o modificar datos según sea necesario. Por ejemplo, una base de datos que almacena información en tiempo real, como un sistema de reservas de vuelos o una aplicación de redes sociales.
* **Bases de datos distribuidas**: Son aquellas que se encuentran distribuidas en múltiples ubicaciones físicas, permitiendo a los usuarios acceder a la información desde diferentes lugares. Este tipo de bases de datos es útil para organizaciones con múltiples sucursales o para aplicaciones que requieren alta disponibilidad y tolerancia a fallos.

## Modelos de datos

Es importante mencionar que los modelos de datos son representaciones abstractas de la estructura y organización de la información en una base de datos. Estos modelos definen cómo se almacenan, organizan y relacionan los datos, y proporcionan un marco conceptual para diseñar y gestionar bases de datos de manera eficiente.

Existen diferentes modelos de datos, cada uno con sus propias características y ventajas. Algunos de los modelos más comunes incluyen:

* **Modelo jerárquico**: Organiza los datos en una estructura de árbol, donde cada registro tiene un único padre y puede tener múltiples hijos. Este modelo es útil para representar relaciones jerárquicas, como la estructura de una organización o un catálogo de productos.
* **Modelo de red**: Permite representar relaciones más complejas entre los datos, utilizando nodos y aristas para establecer conexiones entre los registros. Este modelo es útil para aplicaciones que requieren una representación más flexible de las relaciones entre los datos, como sistemas de gestión de redes o aplicaciones de logística.
* **Modelo relacional**: Organiza los datos en tablas con filas y columnas, y utiliza un lenguaje de consulta estructurado (SQL) para acceder y manipular la información. Este modelo es ampliamente utilizado en aplicaciones empresariales y sistemas de gestión de datos, ya que permite realizar consultas complejas y mantener la integridad de los datos mediante el uso de claves primarias y foráneas.
* **Modelo orientado a objetos**: Almacena los datos como objetos, que incluyen tanto los datos como los métodos asociados. Este modelo es ideal para aplicaciones que requieren una representación más natural de los datos y permite una mayor flexibilidad en la gestión de la información, especialmente en aplicaciones que utilizan programación orientada a objetos.
* **Modelo NoSQL**: Diseñado para manejar grandes volúmenes de datos no estructurados o semi-estructurados, como documentos, gráficos y datos en tiempo real. Este modelo es ideal para aplicaciones web y móviles que requieren escalabilidad y flexibilidad, y permite almacenar y consultar datos de manera eficiente sin la necesidad de un esquema fijo. Algunos ejemplos de bases de datos NoSQL incluyen MongoDB, Cassandra y Redis, que ofrecen diferentes enfoques para el almacenamiento y la gestión de datos según las necesidades específicas de cada aplicación.

### Modelo Relacional

Vamos a centrarnos en el modelo relacional, ya que es uno de los más utilizados en la actualidad. Este modelo organiza los datos en tablas, donde cada tabla representa una entidad y cada fila representa un registro de esa entidad. Las columnas de la tabla representan los atributos de la entidad.

Un modelo relacional tiene los siguientes componentes principales:

* **Tablas**: Son estructuras que almacenan los datos en filas y columnas. Cada tabla representa una entidad y contiene registros que representan instancias de esa entidad.
* **Filas (Registros)**: Cada fila de una tabla representa un registro individual de la entidad, que contiene valores para cada uno de los atributos definidos en las columnas.
* **Columnas (Atributos)**: Cada columna de una tabla representa un atributo de la entidad, que define el tipo de información que se almacena en esa columna. Por ejemplo, una columna puede representar el nombre, la edad o la dirección de una persona.
* **Claves**: Son atributos o conjuntos de atributos que se utilizan para identificar de manera única cada registro en una tabla. Las claves primarias son aquellas que identifican de manera única un registro, mientras que las claves foráneas se utilizan para establecer relaciones entre tablas, permitiendo vincular datos de diferentes entidades.

### Otros modelos de datos

Además del modelo relacional, existen otros modelos de datos que se utilizan en diferentes contextos y aplicaciones. Algunos de estos modelos incluyen:

* **Modelo Multidimensional**: Es utilizado principalmente en sistemas de almacenamiento de datos y análisis de información, como los sistemas de inteligencia empresarial (BI). Este modelo organiza los datos en estructuras multidimensionales, permitiendo realizar consultas y análisis complejos de manera eficiente.
* **Modelo de Grafos**: Es utilizado para representar relaciones complejas entre datos, utilizando nodos y aristas para establecer conexiones entre los registros. Este modelo es útil para aplicaciones que requieren analizar redes sociales, sistemas de recomendación o cualquier escenario donde las relaciones entre los datos sean fundamentales.

