# Tema 1: Almacenamiento de la información

El presente tema se centra en el almacenamiento de la información, abordando los diferentes métodos y tecnologías utilizados para guardar y gestionar datos de manera eficiente. A lo largo del tema, se explorarán conceptos clave relacionados con el almacenamiento de datos, incluyendo ficheros, bases de datos, sistemas de gestión de bases de datos (SGBD), arquitecturas de bases de datos y normativa relacionada con la protección de datos.

## Objetivos del tema

Los objetivos principales de este tema son:

* Comprender los diferentes métodos de almacenamiento de información y sus características.
* Analizar las ventajas y desventajas de los distintos sistemas de almacenamiento.
* Explorar las tecnologías y herramientas utilizadas para la gestión de datos.
* Conocer la normativa y regulaciones relacionadas con la protección de datos y su importancia en el almacenamiento de información.

## Contenido

El contenido del tema se organiza en las siguientes secciones:

1. Introducción
2. Almacenamiento de datos
3. Ficheros
4. Bases de datos
5. Sistemas de gestión de bases de datos (SGBD)
6. Arquitecturas de bases de datos
7. Big Data e Inteligencia de Negocios (BI)
8. Normativa y protección de datos

## Licencia

El contenido de este tema está bajo la licencia Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) (salvo que se indique lo contrario). Esto significa que puedes compartir y adaptar el material, siempre que se atribuya adecuadamente, no se utilice con fines comerciales y se comparta bajo la misma licencia.

!!! info
    Puedes encontrar más información sobre la licencia en el siguiente enlace: [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-nc-sa/4.0/).

## Versiones

* Septiembre 2026 - Versión 1.0 -  Versión inicial del tema. Curso 2026-27.


