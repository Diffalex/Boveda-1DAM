# Sistemas Gestores de Banco de Datos (SGBD)

Un Sistema Gestor de Base de Datos (SGBD) es un software que permite crear, administrar y manipular bases de datos. Su función principal es proporcionar una interfaz para que los usuarios puedan interactuar con la base de datos, realizar consultas, insertar, actualizar y eliminar datos, así como garantizar la integridad y seguridad de la información.

Los SGBD son fundamentales en la gestión de datos, ya que permiten organizar, almacenar y recuperar información de manera eficiente y segura. Un SGBD proporciona herramientas y funcionalidades que facilitan la administración de bases de datos, como la definición de estructuras de datos, la gestión de usuarios y permisos, la optimización del rendimiento y la realización de copias de seguridad.

Hemos visto que existen diferentes tipos de bases de datos, cada una con sus propias características y ventajas. Los SGBD están diseñados para trabajar con estos diferentes tipos de bases de datos, proporcionando las herramientas necesarias para gestionar la información de manera efectiva.

Un SGDB puede ser utilizado en una amplia variedad de aplicaciones, desde sistemas empresariales y aplicaciones web hasta sistemas de gestión de información en tiempo real. Su capacidad para manejar grandes volúmenes de datos, garantizar la integridad y seguridad de la información, y facilitar el acceso concurrente por parte de múltiples usuarios lo convierte en una herramienta esencial en el mundo actual de la gestión de datos.

### Funciones principales de un SGBD

Las funciones principales de un SGBD incluyen:

* **Definición de estructuras de datos**: Permite definir la estructura de la base de datos, incluyendo tablas, campos, relaciones y restricciones, para garantizar la integridad y consistencia de la información.
* **Gestión de usuarios y permisos**: Permite crear y administrar usuarios, asignar roles y permisos, y controlar el acceso a la información de manera segura.
* **Optimización del rendimiento**: Proporciona herramientas y técnicas para mejorar el rendimiento de la base de datos, como la indexación, la optimización de consultas y la gestión de recursos.
* **Realización de copias de seguridad y recuperación**: Permite realizar copias de seguridad de la base de datos y restaurar la información en caso de pérdida o fallo del sistema, garantizando la disponibilidad y continuidad del servicio.
* **Manejo de transacciones**: Permite gestionar transacciones de manera segura y eficiente, asegurando que las operaciones se realicen de manera completa y consistente, y que se cumplan las propiedades ACID _(Atomicidad, Consistencia, Aislamiento y Durabilidad)_ para garantizar la integridad de los datos.

### Componentes de un SGBD

Un SGBD está compuesto por varios componentes que trabajan juntos para gestionar la base de datos de manera eficiente. Algunos de los componentes principales incluyen:

* **Motor de almacenamiento**: Es el componente encargado de almacenar y recuperar los datos de la base de datos, gestionando el acceso a los archivos físicos y optimizando el rendimiento del sistema.
* **Procesador de consultas**: Es el componente encargado de interpretar y ejecutar las consultas realizadas por los usuarios, optimizando el acceso a los datos y garantizando la eficiencia en la recuperación de información.
* **Gestor de transacciones**: Es el componente encargado de gestionar las transacciones realizadas en la base de datos, asegurando que se cumplan las propiedades ACID y garantizando la integridad y consistencia de la información.
* **Gestor de seguridad**: Es el componente encargado de controlar el acceso a la base de datos, gestionando usuarios, roles y permisos, y garantizando la protección de la información contra accesos no autorizados y posibles amenazas de seguridad.


## Arquitectura de un SGBD

La arquitectura de un SGBD se puede dividir en varias capas, cada una con un propósito específico. Estas capas incluyen:

* **Nivel físico**: Es la capa más baja de la arquitectura, encargada de gestionar el almacenamiento físico de los datos en el sistema de archivos y optimizar el acceso a los mismos.
* **Nivel lógico**: Es la capa intermedia de la arquitectura, encargada de definir la estructura lógica de la base de datos, incluyendo tablas, relaciones y restricciones, y garantizar la integridad y consistencia de la información.
* **Nivel de usuario**: Es la capa más alta de la arquitectura, encargada de proporcionar la interfaz de usuario y las herramientas necesarias para interactuar con la base de datos, realizar consultas, insertar, actualizar y eliminar datos, y gestionar usuarios y permisos de manera segura.

Además, la arquitectura de un SGBD puede incluir componentes adicionales, como sistemas de replicación, balanceadores de carga y herramientas de monitoreo, que mejoran la disponibilidad, escalabilidad y rendimiento del sistema.

También es importante destacar que se pueden dividir los SGDB en dos grandes grupos según su arquitectura:

* **SGBD centralizados**: En este tipo de arquitectura, la base de datos se encuentra en un único servidor centralizado, y los usuarios acceden a ella a través de una red. Este enfoque es más sencillo de implementar y administrar, pero puede presentar limitaciones en términos de escalabilidad y disponibilidad.
* **SGBD distribuidos**: En este tipo de arquitectura, la base de datos se encuentra distribuida en varios servidores o nodos, que pueden estar ubicados en diferentes ubicaciones geográficas. Este enfoque permite una mayor escalabilidad y disponibilidad, pero puede ser más complejo de implementar y administrar debido a la necesidad de sincronización y coordinación entre los nodos.

## Catálogo de SGBD

Veamos algunos de los SGBD más populares y ampliamente utilizados en la industria:

### SGBD Privativos

* **Oracle Database**: Es un SGBD relacional desarrollado por Oracle Corporation. Es conocido por su robustez, escalabilidad y capacidad para manejar grandes volúmenes de datos. Oracle Database ofrece una amplia gama de características avanzadas, como replicación, particionamiento y soporte para transacciones distribuidas, lo que lo convierte en una opción popular para aplicaciones empresariales críticas.
* **Microsoft SQL Server**: Es un SGBD relacional desarrollado por Microsoft. Es ampliamente utilizado en entornos empresariales y ofrece una integración sólida con otras herramientas de Microsoft, como Visual Studio y Power BI. SQL Server proporciona características avanzadas de seguridad, rendimiento y escalabilidad, lo que lo convierte en una opción popular para aplicaciones empresariales y soluciones de análisis de datos.
* **IBM Db2**: Es un SGBD relacional desarrollado por IBM. Es conocido por su capacidad para manejar grandes volúmenes de datos y su enfoque en la seguridad y el rendimiento. Db2 ofrece características avanzadas de replicación, particionamiento y soporte para transacciones distribuidas, lo que lo convierte en una opción popular para aplicaciones empresariales críticas y soluciones de análisis de datos.

### SGBD de Código Abierto

* **MySQL (MariaDB)**: Es un SGBD relacional de código abierto desarrollado por Oracle Corporation. Es ampliamente utilizado en aplicaciones web y es conocido por su facilidad de uso, rendimiento y escalabilidad. MySQL ofrece características avanzadas como replicación, particionamiento y soporte para transacciones distribuidas, lo que lo convierte en una opción popular para aplicaciones web y soluciones de análisis de datos.

* **PostgreSQL**: Es un SGBD relacional de código abierto conocido por su robustez, escalabilidad y cumplimiento de estándares SQL. PostgreSQL ofrece características avanzadas como replicación, particionamiento y soporte para transacciones distribuidas, lo que lo convierte en una opción popular para aplicaciones empresariales y soluciones de análisis de datos. Además, PostgreSQL es altamente extensible, lo que permite a los desarrolladores agregar nuevas funcionalidades mediante la creación de extensiones personalizadas.

* **MongoDB**: Es un SGBD NoSQL de código abierto que utiliza un modelo de datos basado en documentos. MongoDB es conocido por su flexibilidad, escalabilidad y capacidad para manejar grandes volúmenes de datos no estructurados. Ofrece características avanzadas como replicación, particionamiento y soporte para transacciones distribuidas, lo que lo convierte en una opción popular para aplicaciones web y soluciones de análisis de datos en tiempo real.

!!! info
    MariaDB es un fork de MySQL, creado por los desarrolladores originales de MySQL después de que Oracle adquiriera Sun Microsystems. MariaDB se ha convertido en una alternativa popular a MySQL, ofreciendo compatibilidad con la mayoría de las aplicaciones y herramientas que funcionan con MySQL, así como mejoras en el rendimiento y la seguridad.