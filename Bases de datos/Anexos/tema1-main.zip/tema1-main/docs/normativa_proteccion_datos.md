# Normativa y Protección de datos

A la hora de trabajar con datos, es fundamental tener en cuenta la normativa y las leyes de protección de datos que regulan el uso, almacenamiento y tratamiento de la información personal. Estas normativas buscan garantizar la privacidad y seguridad de los datos de los individuos, así como establecer responsabilidades para las organizaciones que manejan dicha información.

Existen diferentes leyes y regulaciones a nivel nacional e internacional que establecen los principios y requisitos para el manejo de datos personales. Algunas de las normativas más relevantes incluyen:

* **Reglamento General de Protección de Datos (RGPD)**: Es una normativa de la Unión Europea que establece las reglas para el tratamiento de datos personales y la protección de la privacidad de los ciudadanos europeos. El RGPD establece principios como la transparencia, la limitación del propósito, la minimización de datos y la seguridad de los datos, así como derechos para los individuos, como el derecho al acceso, rectificación y eliminación de sus datos personales.
* **Ley de Protección de Datos Personales (LPDP)**: Es una ley nacional que regula el tratamiento de datos personales en un país específico. La LPDP establece los principios y obligaciones para las organizaciones que manejan datos personales, así como los derechos de los individuos en relación con sus datos.

Es por ello, que es fundamental que las organizaciones implementen políticas y procedimientos adecuados para cumplir con estas normativas y garantizar la protección de los datos personales. Esto incluye la implementación de medidas de seguridad, la capacitación del personal, la obtención del consentimiento adecuado para el tratamiento de datos y la realización de auditorías periódicas para evaluar el cumplimiento de las normativas.

Para cumplir con la normativa y proteger los datos personales, las organizaciones deben considerar aspectos como:

* **Seguridad de la información**: Implementar medidas de seguridad técnicas y organizativas para proteger los datos personales contra accesos no autorizados, pérdida o destrucción. Esto puede incluir el uso de cifrado, autenticación de usuarios, control de acceso y copias de seguridad.
* **Gestión de consentimientos**: Obtener el consentimiento explícito de los individuos para el tratamiento de sus datos personales, asegurando que comprendan cómo se utilizarán sus datos y brindándoles la opción de retirar su consentimiento en cualquier momento.
* **Transparencia y comunicación**: Proporcionar información clara y accesible sobre cómo se recopilan, utilizan y protegen los datos personales, así como los derechos de los individuos en relación con sus datos.

También es importante destacar que el incumplimiento de las normativas de protección de datos puede tener consecuencias legales y financieras significativas para las organizaciones, incluyendo sanciones económicas y daños a la reputación. Por lo tanto, es esencial que las organizaciones se mantengan actualizadas sobre las leyes y regulaciones aplicables y adopten prácticas de gestión de datos responsables y éticas.

### Principios de protección de datos

A la hora de trabajar con los datos necesitamos que tener en cuenta los principios de protección de datos, que son los fundamentos que guían el tratamiento de la información personal y garantizan la privacidad y seguridad de los individuos. Algunos de los principios más importantes incluyen:

1. **Licitud, Lealtad y Transparencia:** Los datos deben recogerse con consentimiento explícito e informado.
2. **Limitación de la Finalidad:** Prohibido utilizar los datos para fines distintos a los informados inicialmente.
3. **Minimización de Datos:** Los esquemas de BD deben almacenar **únicamente** los datos estrictamente necesarios.
4. **Exactitud:** Los datos deben mantenerse actualizados y corregirse inmediatamente si son inexactos.
5. **Limitación del Plazo de Conservación:** Los registros deben borrarse o anonimizarse cuando dejen de ser necesarios.
6. **Integridad y Confidencialidad:** Obligación de garantizar la seguridad proactiva (*Privacidad desde el Diseño y por Defecto*).

### Impacto de la normativa en el diseño de bases de datos

Cuando diseñamos bases de datos, es fundamental tener en cuenta la normativa y los principios de protección de datos para garantizar que la información personal se maneje de manera segura y ética. Esto implica considerar diferentes aspectos en el diseño de la base de datos, como la estructura de los datos, los permisos de acceso, las medidas de seguridad y los procedimientos de gestión de datos.

| Aspecto | Consideraciones |
|---------|----------------|
| Estructura de los datos | Diseñar la base de datos de manera que se minimice la cantidad de datos personales almacenados y se cumpla con el principio de minimización de datos. Esto puede implicar la normalización de los datos, la eliminación de redundancias y la implementación de mecanismos de anonimización o seudonimización cuando sea posible. |
| Permisos de acceso | Establecer roles y permisos de acceso adecuados para garantizar que solo los usuarios autorizados puedan acceder a los datos personales. Esto puede incluir la implementación de autenticación de usuarios, control de acceso basado en roles y auditorías de acceso para monitorear el uso de los datos. |
| Medidas de seguridad | Implementar medidas de seguridad técnicas y organizativas para proteger los datos personales contra accesos no autorizados, pérdida o destrucción. Esto puede incluir el uso de cifrado, firewalls, sistemas de detección de intrusiones y políticas de seguridad de la información. |
| Procedimientos de gestión de datos | Establecer procedimientos claros para la gestión de datos personales, incluyendo la obtención del consentimiento, la gestión de solicitudes de acceso y rectificación, la eliminación de datos cuando ya no sean necesarios y la realización de auditorías periódicas para evaluar el cumplimiento de la normativa. Esto puede implicar la creación de políticas de privacidad, la capacitación del personal y la implementación de sistemas de gestión de datos que faciliten el cumplimiento de la normativa. |

### Medidas de seguridad y buenas prácticas

Algunas de las medidas de seguridad y buenas prácticas que se pueden implementar en el diseño de bases de datos para cumplir con la normativa de protección de datos incluyen:

* **Registro de Actividades de Tratamiento (RAT):** Documentación obligatoria del inventario de datos y flujos de información.
* **Delegado de Protección de Datos (DPD / DPO):** Figura encargada de supervisar el cumplimiento normativo en las organizaciones.
* **Evaluación de Impacto (EIPD):** Análisis previo de riesgos antes de desplegar bases de datos que procesen datos sensibles a gran escala.